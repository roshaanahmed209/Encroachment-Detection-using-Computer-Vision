# Encroachment > 2024-11-28 3:10pm
https://universe.roboflow.com/encroachment/encroachment-dwic8

Provided by a Roboflow user
License: CC BY 4.0

