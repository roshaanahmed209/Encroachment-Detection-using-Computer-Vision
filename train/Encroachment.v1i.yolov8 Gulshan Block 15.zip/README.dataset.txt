# Encroachment > 2024-11-27 12:29am
https://universe.roboflow.com/encroachment/encroachment-dwic8

Provided by a Roboflow user
License: CC BY 4.0

